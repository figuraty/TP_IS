public class CountryDTO {
    private String name;

    public CountryDTO(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
