public class Payload {
    private String name;
    private String type;


    // Getter Methods

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    // Setter Methods

    public void setName(String name) {
        this.name = name;
    }

    public void setType(String type) {
        this.type = type;
    }
}
