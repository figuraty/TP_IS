
public class ReadTopicObject {
    Schema schema;
    Payload payload;


    // Getter Methods

    public Schema getSchema() {
        return schema;
    }

    public Payload getPayload() {
        return payload;
    }

    // Setter Methods

    public void setSchema(Schema schemaObject) {
        this.schema = schemaObject;
    }

    public void setPayload(Payload payloadObject) {
        this.payload = payloadObject;
    }
}





