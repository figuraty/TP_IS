//package rest;
//
//import javax.ws.rs.ApplicationPath;
//import javax.ws.rs.core.Application;
//
//@ApplicationPath("webapi")
//public class WebAPI extends Application {
//}

package rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("webapi")
public class WebAPI extends Application {
}