package data.dtos;

public class ItemDTO {
    private String name;

    public ItemDTO(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
